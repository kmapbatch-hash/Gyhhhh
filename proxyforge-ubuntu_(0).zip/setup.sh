#!/bin/bash
# ProxyForge Ubuntu Edition - Setup Script
# Run: chmod +x setup.sh && ./setup.sh

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${GREEN}   ProxyForge Ubuntu Edition${NC}"
echo -e "${BLUE}========================================${NC}"

# Detect if running in chroot/Termux proot
if [ -f /etc/os-release ]; then
    . /etc/os-release
    echo -e "${GREEN}[*] OS detected: $NAME $VERSION_ID${NC}"
else
    echo -e "${YELLOW}[!] Unknown OS, assuming Debian/Ubuntu compatible${NC}"
fi

# ============================================================
# FIX: Update Rust to latest version if outdated
# ============================================================
echo -e "${BLUE}[*] Checking Rust version...${NC}"

if command -v rustc &> /dev/null; then
    CURRENT_RUST=$(rustc --version | awk '{print $2}')
    echo -e "${GREEN}[*] Current Rust: $CURRENT_RUST${NC}"

    # Check if rustup exists (managed installation)
    if command -v rustup &> /dev/null; then
        echo -e "${BLUE}[*] Updating Rust via rustup...${NC}"
        rustup self update || true
        rustup update stable || true
        source "$HOME/.cargo/env" || true
    else
        # Rust installed via apt, need to uninstall and use rustup
        echo -e "${YELLOW}[!] Rust installed via apt (old version). Switching to rustup...${NC}"
        echo -e "${YELLOW}[!] Removing old Rust installation...${NC}"
        apt-get remove -y rustc cargo || sudo apt-get remove -y rustc cargo || true

        echo -e "${BLUE}[*] Installing rustup (latest Rust)...${NC}"
        curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
        source "$HOME/.cargo/env"
    fi
else
    echo -e "${BLUE}[*] Rust not found. Installing via rustup...${NC}"
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
    source "$HOME/.cargo/env"
fi

# Verify new version
NEW_RUST=$(rustc --version | awk '{print $2}')
echo -e "${GREEN}[*] Rust version now: $NEW_RUST${NC}"

# ============================================================
# Install system dependencies
# ============================================================
echo -e "${BLUE}[*] Updating package list...${NC}"
apt-get update -y || sudo apt-get update -y || true

echo -e "${BLUE}[*] Installing system dependencies...${NC}"
apt-get install -y python3 python3-pip python3-venv curl wget git build-essential \
    libssl-dev pkg-config || sudo apt-get install -y python3 python3-pip python3-venv \
    curl wget git build-essential libssl-dev pkg-config || true

# ============================================================
# Python virtual environment
# ============================================================
echo -e "${BLUE}[*] Creating Python virtual environment...${NC}"
python3 -m venv venv
source venv/bin/activate

echo -e "${BLUE}[*] Installing Python packages...${NC}"
pip install --upgrade pip
pip install flask aiohttp aiofiles requests

# ============================================================
# Build Rust checker core
# ============================================================
echo -e "${BLUE}[*] Building Rust checker core...${NC}"
cd checker_core
cargo build --release
cd ..

if [ -f "checker_core/target/release/checker_core" ]; then
    cp checker_core/target/release/checker_core ./checker_bin
    chmod +x checker_bin
    echo -e "${GREEN}[+] Rust checker built successfully${NC}"
else
    echo -e "${YELLOW}[!] Rust build failed, Python fallback will be used${NC}"
fi

# ============================================================
# Finalize
# ============================================================
echo -e "${BLUE}[*] Creating directories...${NC}"
mkdir -p proxies/scraped proxies/working proxies/fast

echo -e ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}   SETUP COMPLETE!${NC}"
echo -e "${GREEN}========================================${NC}"
echo -e ""
echo -e "${BLUE}How to run:${NC}"
echo -e "  ${YELLOW}source venv/bin/activate${NC}"
echo -e "  ${YELLOW}python3 run.py${NC}"
echo -e ""
echo -e "${BLUE}Or use the runner:${NC}"
echo -e "  ${YELLOW}./run.sh${NC}"
echo -e ""
echo -e "${BLUE}Then open browser:${NC}"
echo -e "  ${YELLOW}http://localhost:8080${NC}"
echo -e ""
echo -e "${GREEN}========================================${NC}"
