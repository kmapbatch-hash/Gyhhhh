#!/bin/bash
# ProxyForge - Rust Updater
# Jalankan ini kalau Rust version terlalu lama untuk build checker

echo "========================================"
echo "   ProxyForge Rust Updater"
echo "========================================"

if command -v rustup &> /dev/null; then
    echo "[*] rustup ditemukan. Update Rust..."
    rustup self update
    rustup update stable
    source "$HOME/.cargo/env"
    echo "[*] Rust version sekarang: $(rustc --version)"
else
    echo "[!] rustup TIDAK ditemukan."
    echo "[*] Menghapus Rust lama (apt) dan install rustup..."

    # Hapus Rust dari apt kalau ada
    apt-get remove -y rustc cargo 2>/dev/null || sudo apt-get remove -y rustc cargo 2>/dev/null || true

    # Install rustup (latest)
    echo "[*] Download rustup installer..."
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y

    # Aktifkan
    source "$HOME/.cargo/env"

    echo "[*] Rust version sekarang: $(rustc --version)"
fi

echo ""
echo "[*] Build checker core..."
cd checker_core
cargo build --release
cd ..

if [ -f "checker_core/target/release/checker_core" ]; then
    cp checker_core/target/release/checker_core ./checker_bin
    chmod +x checker_bin
    echo "[+] Build berhasil!"
else
    echo "[!] Build gagal. Checker akan pakai Python fallback."
fi
