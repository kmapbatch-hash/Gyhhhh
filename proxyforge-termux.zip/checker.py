#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ProxyForge Termux Edition - Proxy Checker
Python checker with optional Rust core fallback
"""
import os
import sys
import json
import asyncio
import aiohttp
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

class ProxyChecker:
    def __init__(self, log_callback=None, progress_callback=None, use_rust=True):
        self.log = log_callback or print
        self.progress = progress_callback or (lambda x: None)
        self.use_rust = use_rust
        self.stop_flag = False
        self.results = []
        self.rust_bin = os.path.join(os.path.dirname(__file__), "checker_bin")

    def _run_rust(self, input_file, output_file, test_url, timeout, threads, proxy_type):
        if not os.path.exists(self.rust_bin):
            return False
        cmd = f"{self.rust_bin} {input_file} {output_file} {test_url} {timeout} {threads} {proxy_type}"
        self.log(f"[*] Menjalankan Rust checker...")
        import subprocess
        try:
            proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, 
                                   stderr=subprocess.STDOUT, text=True)
            for line in proc.stdout:
                line = line.strip()
                if line:
                    self.log(line)
            proc.wait(timeout=300)
            return os.path.exists(output_file) and os.path.getsize(output_file) > 10
        except Exception as e:
            self.log(f"[!] Rust error: {e}")
            return False

    async def _check_one(self, session, proxy_str, test_url, timeout, proxy_type):
        if self.stop_flag:
            return None
        start = time.time()
        try:
            proxy_url = f"http://{proxy_str}"
            async with session.get(test_url, proxy=proxy_url, 
                                  timeout=aiohttp.ClientTimeout(total=timeout),
                                  ssl=False) as resp:
                elapsed = round((time.time() - start) * 1000, 2)
                if resp.status == 200:
                    return {
                        "proxy": proxy_str,
                        "type": proxy_type,
                        "response_time": elapsed,
                        "status": "WORKING",
                        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    }
        except Exception:
            pass
        return None

    async def run_python(self, proxies, test_url="http://www.google.com", timeout=10, threads=50, proxy_type="HTTP"):
        self.results = []
        self.stop_flag = False
        total = len(proxies)
        checked = 0

        connector = aiohttp.TCPConnector(limit=threads, limit_per_host=threads, ssl=False)
        async with aiohttp.ClientSession(connector=connector) as session:
            sem = asyncio.Semaphore(threads)

            async def bounded_check(p):
                nonlocal checked
                async with sem:
                    if self.stop_flag:
                        return None
                    res = await self._check_one(session, p, test_url, timeout, proxy_type)
                    checked += 1
                    self.progress(int(checked / total * 100))
                    return res

            tasks = [bounded_check(p) for p in proxies]
            for coro in asyncio.as_completed(tasks):
                if self.stop_flag:
                    break
                res = await coro
                if res:
                    self.results.append(res)
                    self.log(f"[WORKING] {res['proxy']} - {res['response_time']}ms")

        return self.results

    def run(self, proxies, test_url="http://www.google.com", timeout=10, threads=50, proxy_type="HTTP"):
        input_file = "proxies/_check_input.txt"
        output_file = "proxies/_check_output.json"
        os.makedirs("proxies", exist_ok=True)

        with open(input_file, "w") as f:
            for p in proxies:
                f.write(f"{p}\n")

        if self.use_rust and os.path.exists(self.rust_bin):
            self.log("[*] Menggunakan Rust checker core...")
            ok = self._run_rust(input_file, output_file, test_url, timeout, threads, proxy_type)
            if ok:
                try:
                    with open(output_file) as f:
                        data = json.load(f)
                    self.results = data.get("working", [])
                    self.log(f"[*] Rust checker selesai. Working: {len(self.results)}")
                    return self.results
                except Exception as e:
                    self.log(f"[!] Rust output error: {e}")
            self.log("[!] Rust gagal, fallback ke Python...")

        self.log("[*] Menggunakan Python checker...")
        return asyncio.run(self.run_python(proxies, test_url, timeout, threads, proxy_type))
