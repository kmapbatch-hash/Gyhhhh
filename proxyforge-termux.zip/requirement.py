#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ProxyForge Termux Edition - Setup Installer
Installs all dependencies and builds Rust checker
"""
import os
import sys
import subprocess
import shutil

TERMUX = os.path.exists('/data/data/com.termux/files/usr/bin/pkg')

def run(cmd, shell=True, check=False):
    print(f"\n[RUN] {cmd}")
    r = subprocess.run(cmd, shell=shell)
    if check and r.returncode != 0:
        print(f"[ERROR] Command failed: {cmd}")
    return r

def main():
    print("=" * 60)
    print("   ProxyForge Termux Edition - Setup Installer")
    print("=" * 60)

    base_dir = os.path.dirname(os.path.abspath(__file__))

    if TERMUX:
        print("[*] Termux detected!")
        print("[*] Installing system packages...")
        run("pkg update -y", check=False)
        run("pkg install -y python rust git openssl libffi -y", check=False)
        run("pkg install -y cargo -y", check=False)
    else:
        print("[!] Non-Termux environment detected.")
        print("[!] Ensure Python 3.8+ and Rust/Cargo are installed.")

    print("[*] Installing Python dependencies...")
    run("pip install --upgrade pip", check=False)
    run("pip install flask aiohttp aiofiles requests", check=False)

    print("[*] Building Rust checker core...")
    rust_dir = os.path.join(base_dir, "checker_core")
    if os.path.exists(os.path.join(rust_dir, "Cargo.toml")):
        print(f"[*] Found Rust project at: {rust_dir}")
        build_cmd = f"cd {rust_dir} && cargo build --release"
        result = run(build_cmd, check=False)

        bin_src = os.path.join(rust_dir, "target", "release", "checker_core")
        bin_dst = os.path.join(base_dir, "checker_bin")

        if os.path.exists(bin_src):
            shutil.copy(bin_src, bin_dst)
            os.chmod(bin_dst, 0o755)
            print(f"[+] Rust checker built successfully: {bin_dst}")
        else:
            print("[!] Rust build may have failed.")
            print("[!] Checker will fallback to Python (slower but works).")
            print("[!] To retry Rust build manually:")
            print(f"    cd {rust_dir} && cargo build --release")
    else:
        print("[!] Rust source not found. Skipping build.")

    print("[*] Creating directories...")
    for d in ["proxies/scraped", "proxies/working", "proxies/fast"]:
        os.makedirs(os.path.join(base_dir, d), exist_ok=True)

    print("\n" + "=" * 60)
    print("   SETUP COMPLETE!")
    print("=" * 60)
    print("\n   Cara menjalankan:")
    print("   1. python run.py")
    print("   2. Buka browser: http://localhost:8080")
    print("\n   Atau langsung:")
    print("   python app.py")
    print("=" * 60)

if __name__ == "__main__":
    main()
