#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ProxyForge Termux Edition - Web Panel
Flask server serving web UI for scraping & checking proxies
"""
import os
import sys
import json
import threading
import time
import asyncio
from flask import Flask, render_template, jsonify, request

# Import our engines
from scraper import ProxyScraper, ALL_SOURCES
from checker import ProxyChecker

app = Flask(__name__, template_folder="templates", static_folder="static")

# Global state
state = {
    "scraping": False,
    "checking": False,
    "scraped_proxies": [],
    "working_proxies": [],
    "fast_proxies": [],
    "bad_proxies": [],
    "scraped_count": 0,
    "working_count": 0,
    "bad_count": 0,
    "fast_count": 0,
    "scrape_progress": 0,
    "check_progress": 0,
    "logs": [],
    "avg_time": 0.0,
    "fastest_proxy": None,
    "fastest_time": float('inf'),
    "total_sources": len(ALL_SOURCES),
}

FAST_THRESHOLD = 1000  # ms


def add_log(msg, level="info"):
    timestamp = time.strftime("%H:%M:%S")
    entry = {"time": timestamp, "msg": msg, "level": level}
    state["logs"].append(entry)
    if len(state["logs"]) > 500:
        state["logs"] = state["logs"][-500:]


def save_proxies(filename, proxies):
    path = os.path.join("proxies", filename)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        for p in proxies:
            f.write(f"{p}\n")
    return path


def load_proxies(filename):
    path = os.path.join("proxies", filename)
    if not os.path.exists(path):
        return []
    with open(path) as f:
        return [line.strip() for line in f if line.strip()]


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/status")
def api_status():
    return jsonify(state)


@app.route("/api/scrape", methods=["POST"])
def api_scrape():
    if state["scraping"]:
        return jsonify({"error": "Already scraping"}), 400
    data = request.get_json() or {}
    max_results = data.get("max_results")
    workers = data.get("workers", 15)
    if max_results:
        try:
            max_results = int(max_results)
        except:
            max_results = None

    state["scraping"] = True
    state["scraped_proxies"] = []
    state["scrape_progress"] = 0
    state["scraped_count"] = 0
    add_log(f"[*] Scrape dimulai. Sumber: {len(ALL_SOURCES)} | Workers: {workers}", "info")

    def do_scrape():
        try:
            scraper = ProxyScraper(
                log_callback=lambda m: add_log(m, "info" if "+" in m else ("success" if "selesai" in m else "warning")),
                progress_callback=lambda p: state.update({"scrape_progress": p})
            )
            proxies = asyncio.run(scraper.run(max_results=max_results, workers=workers))
            state["scraped_proxies"] = proxies
            state["scraped_count"] = len(proxies)
            save_proxies("scraped/scraped.txt", proxies)
            add_log(f"[*] Scrape selesai. {len(proxies)} proxy unik ditemukan.", "success")
        except Exception as e:
            add_log(f"[!] Error saat scrape: {str(e)}", "error")
        finally:
            state["scraping"] = False

    threading.Thread(target=do_scrape, daemon=True).start()
    return jsonify({"ok": True, "message": "Scrape started", "sources": len(ALL_SOURCES)})


@app.route("/api/check", methods=["POST"])
def api_check():
    if state["checking"]:
        return jsonify({"error": "Already checking"}), 400
    data = request.get_json() or {}
    proxies = data.get("proxies", state["scraped_proxies"])
    if not proxies:
        # Try load from file
        proxies = load_proxies("scraped/scraped.txt")
    if not proxies:
        return jsonify({"error": "No proxies to check. Scrape first or provide proxies."}), 400

    test_url = data.get("test_url", "http://www.google.com")
    timeout = data.get("timeout", 10)
    threads = data.get("threads", 50)
    proxy_type = data.get("proxy_type", "HTTP")
    use_rust = data.get("use_rust", True)

    state["checking"] = True
    state["working_proxies"] = []
    state["fast_proxies"] = []
    state["bad_proxies"] = []
    state["check_progress"] = 0
    state["working_count"] = 0
    state["bad_count"] = 0
    state["fast_count"] = 0
    state["avg_time"] = 0.0
    state["fastest_proxy"] = None
    state["fastest_time"] = float('inf')
    add_log(f"[*] Check dimulai. Total: {len(proxies)} | Type: {proxy_type} | URL: {test_url}", "info")

    def do_check():
        try:
            checker = ProxyChecker(
                log_callback=lambda m: add_log(m, "success" if "WORKING" in m else "info"),
                progress_callback=lambda p: state.update({"check_progress": p}),
                use_rust=use_rust
            )
            results = checker.run(proxies, test_url, timeout, threads, proxy_type)

            working = []
            fast = []
            bad = []
            total_time = 0.0

            for r in results:
                working.append(r)
                total_time += r.get("response_time", 0)
                if r.get("response_time", 9999) < FAST_THRESHOLD:
                    fast.append(r)
                if r.get("response_time", 9999) < state["fastest_time"]:
                    state["fastest_time"] = r["response_time"]
                    state["fastest_proxy"] = r["proxy"]

            # Build bad list from proxies that didn't work
            working_set = {r["proxy"] for r in results}
            for p in proxies:
                if p not in working_set:
                    bad.append({"proxy": p, "type": proxy_type, "reason": "BAD"})

            avg = round(total_time / len(working), 2) if working else 0

            state["working_proxies"] = working
            state["fast_proxies"] = fast
            state["bad_proxies"] = bad
            state["working_count"] = len(working)
            state["fast_count"] = len(fast)
            state["bad_count"] = len(bad)
            state["avg_time"] = avg

            save_proxies("working/working.txt", [r["proxy"] for r in working])
            save_proxies("fast/fast.txt", [r["proxy"] for r in fast])

            add_log(f"[*] Check selesai. Working: {len(working)} | Fast: {len(fast)} | Bad: {len(bad)} | Avg: {avg}ms", "success")
        except Exception as e:
            add_log(f"[!] Error saat check: {str(e)}", "error")
        finally:
            state["checking"] = False

    threading.Thread(target=do_check, daemon=True).start()
    return jsonify({"ok": True, "message": "Check started", "total": len(proxies)})


@app.route("/api/stop", methods=["POST"])
def api_stop():
    state["scraping"] = False
    state["checking"] = False
    add_log("[*] Stop diminta oleh user", "warning")
    return jsonify({"ok": True})


@app.route("/api/logs")
def api_logs():
    return jsonify(state["logs"])


@app.route("/api/export/<ftype>")
def api_export(ftype):
    if ftype == "working":
        proxies = [r["proxy"] for r in state["working_proxies"]]
        path = save_proxies("working/working.txt", proxies)
    elif ftype == "fast":
        proxies = [r["proxy"] for r in state["fast_proxies"]]
        path = save_proxies("fast/fast.txt", proxies)
    elif ftype == "scraped":
        proxies = state["scraped_proxies"]
        path = save_proxies("scraped/scraped.txt", proxies)
    elif ftype == "all":
        # Export all results in one file
        lines = []
        lines.append("# ProxyForge Results")
        lines.append(f"# Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append("")
        lines.append("# === WORKING PROXIES ===")
        for r in state["working_proxies"]:
            lines.append(r["proxy"])
        lines.append("")
        lines.append("# === FAST PROXIES (<1000ms) ===")
        for r in state["fast_proxies"]:
            lines.append(r["proxy"])
        path = save_proxies("all_results.txt", lines)
    else:
        return jsonify({"error": "Unknown type"}), 400
    return jsonify({"ok": True, "path": path, "count": len(proxies) if ftype != "all" else len(state["working_proxies"])})


@app.route("/api/sources")
def api_sources():
    return jsonify({
        "total": len(ALL_SOURCES),
        "github": len([s for s in ALL_SOURCES if "github" in s["url"]]),
        "website": len([s for s in ALL_SOURCES if "github" not in s["url"]]),
        "list": [{"name": s["name"], "type": s["type"], "url": s["url"]} for s in ALL_SOURCES]
    })


if __name__ == "__main__":
    print("=" * 60)
    print("   ProxyForge Termux Web Panel")
    print("   Open browser at: http://localhost:8080")
    print(f"   Total sources loaded: {len(ALL_SOURCES)}")
    print("=" * 60)
    app.run(host="0.0.0.0", port=8080, debug=False)
