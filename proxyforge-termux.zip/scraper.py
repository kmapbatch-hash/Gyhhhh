#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ProxyForge Termux Edition - Full Scraper
All sources from ProxyForge v3.6 (GitHub + Website CN/HK + Global)
"""
import asyncio
import aiohttp
import re
import random
import time
from urllib.parse import urlparse

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
}

EXTRA_HEADERS = {
    "www.kuaidaili.com": {"Referer": "https://www.kuaidaili.com/free/", "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8"},
    "www.zdaye.com": {"Referer": "https://www.zdaye.com/free/", "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8"},
    "www.ip3366.net": {"Referer": "http://www.ip3366.net/", "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8"},
    "www.89ip.cn": {"Referer": "https://www.89ip.cn/", "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8"},
}

HOST_CONCURRENCY_LIMITS = {
    "raw.githubusercontent.com": 8,
    "www.kuaidaili.com": 2,
    "www.zdaye.com": 2,
    "www.ip3366.net": 3,
    "www.89ip.cn": 3,
    "www.kxdaili.com": 2,
}

HOST_MIN_DELAY = {
    "www.kuaidaili.com": 1.5,
    "www.zdaye.com": 1.5,
    "www.ip3366.net": 1.0,
    "www.89ip.cn": 1.0,
    "www.kxdaili.com": 1.0,
}

# ============================================================
# GITHUB SOURCES - Full list from ProxyForge v3.6
# ============================================================
GITHUB_SOURCES = [
    {"name": "clarketm/proxy-list", "type": "mixed",
     "url": "https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt"},
    {"name": "monosans/proxy-list", "type": "http",
     "url": "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt"},
    {"name": "proxifly/free-proxy-list", "type": "mixed",
     "url": "https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/all/data.txt"},
    {"name": "vakhov/fresh-proxy-list", "type": "http",
     "url": "https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/http.txt"},
    {"name": "roosterkid/openproxylist", "type": "https",
     "url": "https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt"},
    {"name": "mmpx12/proxy-list", "type": "http",
     "url": "https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt"},
    {"name": "jetkai/proxy-list", "type": "http",
     "url": "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-http.txt"},
    {"name": "ShiftyTR/Proxy-List", "type": "http",
     "url": "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt"},
    {"name": "gfpcom/free-proxy-list", "type": "http",
     "url": "https://raw.githubusercontent.com/wiki/gfpcom/free-proxy-list/lists/http.txt"},
    {"name": "ErcinDedeoglu/proxies", "type": "socks5",
     "url": "https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/socks5.txt"},
    {"name": "VPSLabCloud/VPSLab-Free-Proxy-List", "type": "mixed",
     "url": "https://raw.githubusercontent.com/VPSLabCloud/VPSLab-Free-Proxy-List/main/all_proxies.txt"},
    {"name": "ClearProxy/checked-proxy-list", "type": "mixed",
     "url": "https://raw.githubusercontent.com/ClearProxy/checked-proxy-list/main/http/raw/all.txt"},
    {"name": "proxygenerator1/ProxyGenerator", "type": "http",
     "url": "https://raw.githubusercontent.com/proxygenerator1/ProxyGenerator/main/Stable/http.txt"},
    {"name": "Thordata/awesome-free-proxy-list", "type": "mixed",
     "url": "https://raw.githubusercontent.com/Thordata/awesome-free-proxy-list/main/proxies/all.txt"},
    {"name": "MuRongPIG/Proxy-Master", "type": "http",
     "url": "https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/http.txt"},
    {"name": "prxchk/proxy-list", "type": "http",
     "url": "https://raw.githubusercontent.com/prxchk/proxy-list/main/http.txt"},
    {"name": "Anonym0usWork1221/Free-Proxies", "type": "http",
     "url": "https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/http_proxies.txt"},
    {"name": "Zaeem20/FREE_PROXIES_LIST", "type": "socks4",
     "url": "https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/socks4.txt"},
    {"name": "TuanMinPay/live-proxy", "type": "http",
     "url": "https://raw.githubusercontent.com/tuanminpay/live-proxy/master/http.txt"},
    {"name": "Vann-Dev/proxy-list", "type": "http",
     "url": "https://raw.githubusercontent.com/Vann-Dev/proxy-list/main/proxies/http.txt"},
    {"name": "BreakingTechFr/Proxy_Free", "type": "http",
     "url": "https://raw.githubusercontent.com/BreakingTechFr/Proxy_Free/main/proxies/http.txt"},
    {"name": "zloi-user/hideip.me", "type": "http",
     "url": "https://raw.githubusercontent.com/zloi-user/hideip.me/main/http.txt"},
    {"name": "proxyscrape (mirror)", "type": "mixed",
     "url": "https://api.proxyscrape.com/v4/free-proxy-list/get?request=display_proxies&proxy_format=protocolipport&format=text"},
    {"name": "yuceltoluyag/GoodProxy", "type": "mixed",
     "url": "https://raw.githubusercontent.com/yuceltoluyag/GoodProxy/main/raw.txt"},
    {"name": "zevtyardt/proxy-list", "type": "socks4",
     "url": "https://raw.githubusercontent.com/zevtyardt/proxy-list/main/socks4.txt"},
    {"name": "TheSpeedX/PROXY-List", "type": "http",
     "url": "https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt"},
    {"name": "hookzof/socks5_list", "type": "socks5",
     "url": "https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt"},
    {"name": "Argh94/Proxy-List", "type": "http",
     "url": "https://raw.githubusercontent.com/Argh94/Proxy-List/main/HTTP.txt"},
    {"name": "ebrasha/abdal-proxy-hub", "type": "http",
     "url": "https://raw.githubusercontent.com/ebrasha/abdal-proxy-hub/main/http-proxy-list-by-EbraSha.txt"},
    {"name": "databay-labs/free-proxy-list", "type": "http",
     "url": "https://raw.githubusercontent.com/databay-labs/free-proxy-list/master/http.txt"},
    {"name": "dinoz0rg/proxy-list", "type": "http",
     "url": "https://raw.githubusercontent.com/dinoz0rg/proxy-list/main/checked_proxies/http.txt"},
    {"name": "komutan234/Proxy-List-Free", "type": "http",
     "url": "https://raw.githubusercontent.com/komutan234/Proxy-List-Free/main/proxies/http.txt"},
    {"name": "javadbazokar/PROXY-List", "type": "http",
     "url": "https://raw.githubusercontent.com/javadbazokar/PROXY-List/main/http.txt"},
    {"name": "nguywnben/daily-proxy-updates", "type": "http",
     "url": "https://raw.githubusercontent.com/nguywnben/daily-proxy-updates/main/proxies/http.txt"},
    {"name": "saisuiu/Lionkings-Http-Proxys", "type": "http",
     "url": "https://raw.githubusercontent.com/saisuiu/Lionkings-Http-Proxys-Proxies/main/free.txt"},
    {"name": "almroot/proxylist", "type": "mixed",
     "url": "https://raw.githubusercontent.com/almroot/proxylist/master/list.txt"},
    {"name": "enseitankado/proxine", "type": "socks5",
     "url": "https://raw.githubusercontent.com/enseitankado/proxine/main/socks5.lst"},
    {"name": "proxy4parsing/proxy-list", "type": "http",
     "url": "https://raw.githubusercontent.com/proxy4parsing/proxy-list/main/http.txt"},
    {"name": "opsxcq/proxy-list", "type": "mixed",
     "url": "https://raw.githubusercontent.com/opsxcq/proxy-list/master/list.txt"},
    {"name": "SoliSpirit/proxy-list (http)", "type": "http",
     "url": "https://raw.githubusercontent.com/SoliSpirit/proxy-list/main/http.txt"},
    {"name": "SoliSpirit/proxy-list (socks4)", "type": "socks4",
     "url": "https://raw.githubusercontent.com/SoliSpirit/proxy-list/main/socks4.txt"},
    {"name": "SoliSpirit/proxy-list (socks5)", "type": "socks5",
     "url": "https://raw.githubusercontent.com/SoliSpirit/proxy-list/main/socks5.txt"},
    {"name": "proxylist-to/proxy-list (http)", "type": "http",
     "url": "https://raw.githubusercontent.com/proxylist-to/proxy-list/main/http.txt"},
    {"name": "proxylist-to/proxy-list (socks4)", "type": "socks4",
     "url": "https://raw.githubusercontent.com/proxylist-to/proxy-list/main/socks4.txt"},
    {"name": "proxylist-to/proxy-list (socks5)", "type": "socks5",
     "url": "https://raw.githubusercontent.com/proxylist-to/proxy-list/main/socks5.txt"},
    {"name": "ProxyScraper/ProxyScraper (http)", "type": "http",
     "url": "https://raw.githubusercontent.com/ProxyScraper/ProxyScraper/main/http.txt"},
    {"name": "ProxyScraper/ProxyScraper (socks4)", "type": "socks4",
     "url": "https://raw.githubusercontent.com/ProxyScraper/ProxyScraper/main/socks4.txt"},
    {"name": "ProxyScraper/ProxyScraper (socks5)", "type": "socks5",
     "url": "https://raw.githubusercontent.com/ProxyScraper/ProxyScraper/main/socks5.txt"},
    {"name": "r00tee/Proxy-List (https)", "type": "https",
     "url": "https://raw.githubusercontent.com/r00tee/Proxy-List/main/Https.txt"},
    {"name": "dpangestuw/Free-Proxy (all)", "type": "mixed",
     "url": "https://raw.githubusercontent.com/dpangestuw/Free-Proxy/refs/heads/main/All_proxies.txt"},
    {"name": "dpangestuw/Free-Proxy (http)", "type": "http",
     "url": "https://raw.githubusercontent.com/dpangestuw/Free-Proxy/refs/heads/main/http_proxies.txt"},
    {"name": "dpangestuw/Free-Proxy (socks4)", "type": "socks4",
     "url": "https://raw.githubusercontent.com/dpangestuw/Free-Proxy/refs/heads/main/socks4_proxies.txt"},
    {"name": "dpangestuw/Free-Proxy (socks5)", "type": "socks5",
     "url": "https://raw.githubusercontent.com/dpangestuw/Free-Proxy/refs/heads/main/socks5_proxies.txt"},
    {"name": "ALIILAPRO/Proxy (http)", "type": "http",
     "url": "https://raw.githubusercontent.com/ALIILAPRO/Proxy/main/http.txt"},
    {"name": "ALIILAPRO/Proxy (socks4)", "type": "socks4",
     "url": "https://raw.githubusercontent.com/ALIILAPRO/Proxy/main/socks4.txt"},
    {"name": "ALIILAPRO/Proxy (socks5)", "type": "socks5",
     "url": "https://raw.githubusercontent.com/ALIILAPRO/Proxy/main/socks5.txt"},
    {"name": "hendrikbgr/Free-Proxy-Repo", "type": "mixed",
     "url": "https://raw.githubusercontent.com/hendrikbgr/Free-Proxy-Repo/master/proxy_list.txt"},
    {"name": "Skillter/ProxyGather (checked)", "type": "mixed",
     "url": "https://raw.githubusercontent.com/Skillter/ProxyGather/refs/heads/master/proxies/working-proxies-all.txt"},
    {"name": "hproxy-com/free-proxy-list (all)", "type": "mixed",
     "url": "https://raw.githubusercontent.com/hproxy-com/free-proxy-list/main/all.txt"},
    {"name": "hproxy-com/free-proxy-list (http)", "type": "http",
     "url": "https://raw.githubusercontent.com/hproxy-com/free-proxy-list/main/http.txt"},
    {"name": "hproxy-com/free-proxy-list (socks5)", "type": "socks5",
     "url": "https://raw.githubusercontent.com/hproxy-com/free-proxy-list/main/socks5.txt"},
    {"name": "ProxyScrape/free-proxy-list (http)", "type": "http",
     "url": "https://raw.githubusercontent.com/ProxyScrape/free-proxy-list/main/proxies/protocols/http/data.txt"},
    {"name": "ProxyScrape/free-proxy-list (socks5)", "type": "socks5",
     "url": "https://raw.githubusercontent.com/ProxyScrape/free-proxy-list/main/proxies/protocols/socks5/data.txt"},
    {"name": "berkay-digital/Proxy-Scraper", "type": "http",
     "url": "https://raw.githubusercontent.com/berkay-digital/Proxy-Scraper/main/proxies.txt"},
    {"name": "stormsia/proxy-list (all)", "type": "mixed",
     "url": "https://raw.githubusercontent.com/stormsia/proxy-list/main/working_proxies.txt"},
    {"name": "iplocate/free-proxy-list (all)", "type": "mixed",
     "url": "https://raw.githubusercontent.com/iplocate/free-proxy-list/main/all-proxies.txt"},
    {"name": "iplocate/free-proxy-list (socks5)", "type": "socks5",
     "url": "https://raw.githubusercontent.com/iplocate/free-proxy-list/main/protocols/socks5.txt"},
    {"name": "Ian-Lusule/Proxies (all)", "type": "mixed",
     "url": "https://raw.githubusercontent.com/Ian-Lusule/Proxies/main/proxies/all_proxies.txt"},
]

# ============================================================
# WEBSITE SOURCES - Full list from ProxyForge v3.6
# CN/HK + Global, all verified sources
# ============================================================
WEBSITE_SOURCES = [
    # --- 89ip.cn ---
    {"name": "89ip.cn (num=100)", "type": "mixed",
     "url": "https://www.89ip.cn/tqdl.html?num=100&address=&kill_address=&port=&kill_port=&isp="},
    {"name": "89ip.cn (num=300)", "type": "mixed",
     "url": "https://www.89ip.cn/tqdl.html?num=300&address=&kill_address=&port=&kill_port=&isp="},

    # --- kuaidaili.com ---
    {"name": "kuaidaili 高匿 hal.1", "type": "http",
     "url": "https://www.kuaidaili.com/free/inha/1/"},
    {"name": "kuaidaili 高匿 hal.2", "type": "http",
     "url": "https://www.kuaidaili.com/free/inha/2/"},
    {"name": "kuaidaili 高匿 hal.3", "type": "http",
     "url": "https://www.kuaidaili.com/free/inha/3/"},
    {"name": "kuaidaili 高匿 hal.4", "type": "http",
     "url": "https://www.kuaidaili.com/free/inha/4/"},
    {"name": "kuaidaili 高匿 hal.5", "type": "http",
     "url": "https://www.kuaidaili.com/free/inha/5/"},
    {"name": "kuaidaili 高匿 hal.6", "type": "http",
     "url": "https://www.kuaidaili.com/free/inha/6/"},
    {"name": "kuaidaili 普通 hal.1", "type": "http",
     "url": "https://www.kuaidaili.com/free/intr/1/"},
    {"name": "kuaidaili 普通 hal.2", "type": "http",
     "url": "https://www.kuaidaili.com/free/intr/2/"},
    {"name": "kuaidaili 普通 hal.3", "type": "http",
     "url": "https://www.kuaidaili.com/free/intr/3/"},
    {"name": "kuaidaili 普通 hal.4", "type": "http",
     "url": "https://www.kuaidaili.com/free/intr/4/"},
    {"name": "kuaidaili 普通 hal.5", "type": "http",
     "url": "https://www.kuaidaili.com/free/intr/5/"},

    # --- ip3366.net ---
    {"name": "ip3366 高匿 stype1", "type": "http",
     "url": "http://www.ip3366.net/free/?stype=1"},
    {"name": "ip3366 高匿 stype1 hal.2", "type": "http",
     "url": "http://www.ip3366.net/free/?stype=1&page=2"},
    {"name": "ip3366 高匿 stype1 hal.3", "type": "http",
     "url": "http://www.ip3366.net/free/?stype=1&page=3"},
    {"name": "ip3366 普通 stype2", "type": "http",
     "url": "http://www.ip3366.net/free/?stype=2"},
    {"name": "ip3366 普通 stype2 hal.2", "type": "http",
     "url": "http://www.ip3366.net/free/?stype=2&page=2"},
    {"name": "ip3366 普通 stype2 hal.3", "type": "http",
     "url": "http://www.ip3366.net/free/?stype=2&page=3"},
    {"name": "ip3366 stype3", "type": "mixed",
     "url": "http://www.ip3366.net/free/?stype=3"},
    {"name": "ip3366 stype3 hal.2", "type": "mixed",
     "url": "http://www.ip3366.net/free/?stype=3&page=2"},

    # --- zdaye.com ---
    {"name": "zdaye hal.1", "type": "mixed",
     "url": "https://www.zdaye.com/free/"},
    {"name": "zdaye hal.2", "type": "mixed",
     "url": "https://www.zdaye.com/free/2/"},
    {"name": "zdaye hal.3", "type": "mixed",
     "url": "https://www.zdaye.com/free/3/"},
    {"name": "zdaye hal.4", "type": "mixed",
     "url": "https://www.zdaye.com/free/4/"},
    {"name": "zdaye hal.5", "type": "mixed",
     "url": "https://www.zdaye.com/free/5/"},
    {"name": "zdaye hal.6", "type": "mixed",
     "url": "https://www.zdaye.com/free/6/"},
    {"name": "zdaye hal.7", "type": "mixed",
     "url": "https://www.zdaye.com/free/7/"},
    {"name": "zdaye hal.8", "type": "mixed",
     "url": "https://www.zdaye.com/free/8/"},

    # --- kxdaili.com ---
    {"name": "kxdaili 资讯中心 hal.1", "type": "http",
     "url": "http://www.kxdaili.com/daili.html"},
    {"name": "kxdaili 资讯中心 hal.2", "type": "http",
     "url": "http://www.kxdaili.com/daili/2.html"},
    {"name": "kxdaili 资讯中心 hal.3", "type": "http",
     "url": "http://www.kxdaili.com/daili/3.html"},
    {"name": "kxdaili 资讯中心 hal.4", "type": "http",
     "url": "http://www.kxdaili.com/daili/4.html"},
    {"name": "kxdaili 资讯中心 hal.5", "type": "http",
     "url": "http://www.kxdaili.com/daili/5.html"},
    {"name": "kxdaili 资讯中心 hal.6", "type": "http",
     "url": "http://www.kxdaili.com/daili/6.html"},
    {"name": "kxdaili 资讯中心 hal.7", "type": "http",
     "url": "http://www.kxdaili.com/daili/7.html"},
    {"name": "kxdaili 资讯中心 hal.8", "type": "http",
     "url": "http://www.kxdaili.com/daili/8.html"},
    {"name": "kxdaili 资讯中心 hal.9", "type": "http",
     "url": "http://www.kxdaili.com/daili/9.html"},
    {"name": "kxdaili 资讯中心 hal.10", "type": "http",
     "url": "http://www.kxdaili.com/daili/10.html"},
    {"name": "kxdaili 资讯中心 hal.11", "type": "http",
     "url": "http://www.kxdaili.com/daili/11.html"},

    # --- free-proxy-list.net ---
    {"name": "free-proxy-list.net (New)", "type": "http",
     "url": "https://free-proxy-list.net/en/"},
    {"name": "free-proxy-list.net (Socks)", "type": "mixed",
     "url": "https://free-proxy-list.net/en/socks-proxy.html"},
    {"name": "free-proxy-list.net (US)", "type": "http",
     "url": "https://free-proxy-list.net/en/us-proxy.html"},
    {"name": "free-proxy-list.net (UK)", "type": "http",
     "url": "https://free-proxy-list.net/en/uk-proxy.html"},
    {"name": "free-proxy-list.net (SSL)", "type": "https",
     "url": "https://free-proxy-list.net/en/ssl-proxy.html"},
    {"name": "free-proxy-list.net (Anonymous)", "type": "http",
     "url": "https://free-proxy-list.net/en/anonymous-proxy.html"},
    {"name": "free-proxy-list.net (Google)", "type": "http",
     "url": "https://free-proxy-list.net/en/google-proxy.html"},

    # --- spys.me ---
    {"name": "spys.me (HTTP/HTTPS)", "type": "mixed",
     "url": "http://spys.me/proxy.txt"},
    {"name": "spys.me (SOCKS4/5)", "type": "socks5",
     "url": "http://spys.me/socks.txt"},

    # --- fineproxy.org ---
    {"name": "fineproxy.org (Worldwide)", "type": "mixed",
     "url": "https://fineproxy.org/free-proxy/"},
    {"name": "fineproxy.org (US)", "type": "mixed",
     "url": "https://fineproxy.org/free-proxies/north-america/united-states/"},
    {"name": "fineproxy.org (UK)", "type": "mixed",
     "url": "https://fineproxy.org/free-proxies/europe/united-kingdom/"},
    {"name": "fineproxy.org (Germany)", "type": "mixed",
     "url": "https://fineproxy.org/free-proxies/europe/germany/"},
    {"name": "fineproxy.org (France)", "type": "mixed",
     "url": "https://fineproxy.org/free-proxies/europe/france/"},
    {"name": "fineproxy.org (Netherlands)", "type": "mixed",
     "url": "https://fineproxy.org/free-proxies/europe/netherlands/"},
    {"name": "fineproxy.org (Canada)", "type": "mixed",
     "url": "https://fineproxy.org/free-proxies/north-america/canada/"},
    {"name": "fineproxy.org (Australia)", "type": "mixed",
     "url": "https://fineproxy.org/free-proxies/oceania/australia/"},
    {"name": "fineproxy.org (Japan)", "type": "mixed",
     "url": "https://fineproxy.org/free-proxies/asia/japan/"},
    {"name": "fineproxy.org (Brazil)", "type": "mixed",
     "url": "https://fineproxy.org/free-proxies/south-america/brazil/"},

    # --- openproxylist.xyz ---
    {"name": "openproxylist.xyz (HTTP)", "type": "http",
     "url": "https://www.openproxylist.xyz/http.txt"},
    {"name": "openproxylist.xyz (HTTPS)", "type": "https",
     "url": "https://www.openproxylist.xyz/https.txt"},
    {"name": "openproxylist.xyz (SOCKS4)", "type": "socks4",
     "url": "https://www.openproxylist.xyz/socks4.txt"},
    {"name": "openproxylist.xyz (SOCKS5)", "type": "socks5",
     "url": "https://www.openproxylist.xyz/socks5.txt"},

    # --- proxybros.com ---
    {"name": "proxybros.com (List hal.1)", "type": "mixed",
     "url": "https://proxybros.com/free-proxy-list/"},
    {"name": "proxybros.com (List hal.2)", "type": "mixed",
     "url": "https://proxybros.com/free-proxy-list/2/"},
    {"name": "proxybros.com (Filter HTTP)", "type": "http",
     "url": "https://proxybros.com/free-proxy-list/http/"},
    {"name": "proxybros.com (Filter SOCKS5)", "type": "socks5",
     "url": "https://proxybros.com/free-proxy-list/socks5/"},
    {"name": "proxybros.com (US)", "type": "mixed",
     "url": "https://proxybros.com/free-proxy-list/US/"},
    {"name": "proxybros.com (Indonesia)", "type": "mixed",
     "url": "https://proxybros.com/free-proxy-list/ID/"},

    # --- freeproxy.world ---
    {"name": "freeproxy.world (hal.1)", "type": "mixed",
     "url": "https://www.freeproxy.world/"},
    {"name": "freeproxy.world (hal.2)", "type": "mixed",
     "url": "https://www.freeproxy.world/?page=2"},
    {"name": "freeproxy.world (hal.3)", "type": "mixed",
     "url": "https://www.freeproxy.world/?page=3"},
    {"name": "freeproxy.world (hal.4)", "type": "mixed",
     "url": "https://www.freeproxy.world/?page=4"},
    {"name": "freeproxy.world (hal.5)", "type": "mixed",
     "url": "https://www.freeproxy.world/?page=5"},
    {"name": "freeproxy.world (hal.6)", "type": "mixed",
     "url": "https://www.freeproxy.world/?page=6"},
    {"name": "freeproxy.world (US)", "type": "mixed",
     "url": "https://www.freeproxy.world/?country=US"},
    {"name": "freeproxy.world (UK)", "type": "mixed",
     "url": "https://www.freeproxy.world/?country=GB"},

    # --- freeproxylist.cc ---
    {"name": "freeproxylist.cc (hal.1)", "type": "mixed",
     "url": "https://freeproxylist.cc/"},
    {"name": "freeproxylist.cc (hal.2)", "type": "mixed",
     "url": "https://freeproxylist.cc/servers/2.html"},
    {"name": "freeproxylist.cc (hal.3)", "type": "mixed",
     "url": "https://freeproxylist.cc/servers/3.html"},
    {"name": "freeproxylist.cc (hal.4)", "type": "mixed",
     "url": "https://freeproxylist.cc/servers/4.html"},
    {"name": "freeproxylist.cc (hal.5)", "type": "mixed",
     "url": "https://freeproxylist.cc/servers/5.html"},
    {"name": "freeproxylist.cc (US)", "type": "mixed",
     "url": "https://freeproxylist.cc/online/United+States/"},
    {"name": "freeproxylist.cc (UK)", "type": "mixed",
     "url": "https://freeproxylist.cc/online/United+Kingdom/"},

    # --- proxyfreeonly.com ---
    {"name": "proxyfreeonly.com (Worldwide)", "type": "mixed",
     "url": "https://proxyfreeonly.com/free-proxy-list"},
    {"name": "proxyfreeonly.com (US)", "type": "mixed",
     "url": "https://proxyfreeonly.com/free-proxy-list/united-states"},
    {"name": "proxyfreeonly.com (Indonesia)", "type": "mixed",
     "url": "https://proxyfreeonly.com/free-proxy-list/indonesia"},
    {"name": "proxyfreeonly.com (Russia)", "type": "mixed",
     "url": "https://proxyfreeonly.com/free-proxy-list/russia"},
    {"name": "proxyfreeonly.com (Netherlands)", "type": "mixed",
     "url": "https://proxyfreeonly.com/free-proxy-list/netherlands"},
    {"name": "proxyfreeonly.com (Philippines)", "type": "mixed",
     "url": "https://proxyfreeonly.com/free-proxy-list/philippines"},
    {"name": "proxyfreeonly.com (Poland)", "type": "mixed",
     "url": "https://proxyfreeonly.com/free-proxy-list/poland"},
    {"name": "proxyfreeonly.com (Thailand)", "type": "mixed",
     "url": "https://proxyfreeonly.com/free-proxy-list/thailand"},
    {"name": "proxyfreeonly.com (Australia)", "type": "mixed",
     "url": "https://proxyfreeonly.com/free-proxy-list/australia"},
    {"name": "proxyfreeonly.com (UK)", "type": "mixed",
     "url": "https://proxyfreeonly.com/free-proxy-list/united-kingdom"},
    {"name": "proxyfreeonly.com (Germany)", "type": "mixed",
     "url": "https://proxyfreeonly.com/free-proxy-list/germany"},
    {"name": "proxyfreeonly.com (Canada)", "type": "mixed",
     "url": "https://proxyfreeonly.com/free-proxy-list/canada"},
    {"name": "proxyfreeonly.com (India)", "type": "mixed",
     "url": "https://proxyfreeonly.com/free-proxy-list/india"},
    {"name": "proxyfreeonly.com (Vietnam)", "type": "mixed",
     "url": "https://proxyfreeonly.com/free-proxy-list/vietnam"},

    # --- vpnside.com ---
    {"name": "vpnside.com (Socks4/5)", "type": "socks5",
     "url": "https://www.vpnside.com/proxy/list/"},

    # --- ab57.ru ---
    {"name": "ab57.ru (proxylist.txt)", "type": "mixed",
     "url": "http://ab57.ru/downloads/proxylist.txt"},
    {"name": "ab57.ru (proxyold.txt)", "type": "mixed",
     "url": "http://ab57.ru/downloads/proxyold.txt"},

    # --- proxyspace.pro ---
    {"name": "proxyspace.pro (http)", "type": "http",
     "url": "https://proxyspace.pro/http.txt"},
    {"name": "proxyspace.pro (https)", "type": "https",
     "url": "https://proxyspace.pro/https.txt"},
    {"name": "proxyspace.pro (socks4)", "type": "socks4",
     "url": "https://proxyspace.pro/socks4.txt"},

    # --- freeproxyupdate.com ---
    {"name": "freeproxyupdate.com (Http)", "type": "http",
     "url": "https://freeproxyupdate.com/http-proxy"},
    {"name": "freeproxyupdate.com (Https-SSL)", "type": "https",
     "url": "https://freeproxyupdate.com/https-ssl-proxy"},
    {"name": "freeproxyupdate.com (SOCKS4)", "type": "socks4",
     "url": "https://freeproxyupdate.com/socks4-proxy"},
    {"name": "freeproxyupdate.com (SOCKS5)", "type": "socks5",
     "url": "https://freeproxyupdate.com/socks5-proxy"},
    {"name": "freeproxyupdate.com (Elite)", "type": "mixed",
     "url": "https://freeproxyupdate.com/elite-proxy"},
]

ALL_SOURCES = GITHUB_SOURCES + WEBSITE_SOURCES

def _dedupe_sources(sources):
    seen_urls = set()
    unique = []
    for src in sources:
        if src["url"] in seen_urls:
            continue
        seen_urls.add(src["url"])
        unique.append(src)
    return unique

ALL_SOURCES = _dedupe_sources(ALL_SOURCES)


def extract_proxies(text):
    """Ekstrak proxy IP:PORT dari teks/HTML mentah.
    4 pola dicoba berurutan, pola pertama yang ketemu langsung dipakai.
    """
    # 1) IP:PORT berdampingan langsung
    direct_pattern = r'\b(?:\d{1,3}\.){3}\d{1,3}:\d{2,5}\b'
    direct = set(re.findall(direct_pattern, text))
    if direct:
        return list(direct)

    # 2) Tabel HTML per-baris/per-sel, TAG-TOLERANT
    pairs = set()
    row_re = re.compile(r'<tr\b[^>]*>(.*?)</tr>', re.IGNORECASE | re.DOTALL)
    cell_re = re.compile(r'<t[dh]\b[^>]*>(.*?)</t[dh]>', re.IGNORECASE | re.DOTALL)
    tag_re = re.compile(r'<[^>]+>')
    ip_only_re = re.compile(r'^(?:\d{1,3}\.){3}\d{1,3}$')
    port_only_re = re.compile(r'^\d{1,5}$')

    for row_match in row_re.finditer(text):
        cells_raw = cell_re.findall(row_match.group(1))
        cells = [re.sub(r'\s+', ' ', tag_re.sub('', c)).strip() for c in cells_raw]
        for i in range(len(cells) - 1):
            ip_candidate = cells[i]
            port_candidate = cells[i + 1]
            if ip_only_re.match(ip_candidate) and port_only_re.match(port_candidate):
                port_num = int(port_candidate)
                if 0 < port_num <= 65535:
                    pairs.add(f"{ip_candidate}:{port_candidate}")
                    break
    if pairs:
        return list(pairs)

    # 3) IP diikuti label "Port：" / "Port:"
    card_pairs = re.findall(
        r'((?:\d{1,3}\.){3}\d{1,3})[^0-9]{1,60}?Port[：:]\s*(\d{2,5})',
        text, flags=re.IGNORECASE
    )
    if card_pairs:
        return list({f"{ip}:{port}" for ip, port in card_pairs})

    # 4) Fallback longgar tanpa label "Port"
    loose_pairs = re.findall(
        r'((?:\d{1,3}\.){3}\d{1,3})[^0-9]{1,20}?\b(\d{2,5})\b(?!\.\d)',
        text
    )
    if loose_pairs:
        return list({f"{ip}:{port}" for ip, port in loose_pairs
                     if 0 < int(port) <= 65535})

    return []


def _looks_like_bot_wall(html):
    """Heuristik kasar: bedakan '200 OK tapi 0 proxy' karena markup berubah
    vs karena diblokir anti-bot/WAF."""
    if len(html) < 2000:
        return True
    lowered = html.lower()
    has_table_markup = "<td" in lowered or "<table" in lowered
    spa_shell_markers = ('id="app"', "id='app'", 'id="root"', "id='root'")
    if not has_table_markup and any(m in lowered for m in spa_shell_markers):
        return True
    return False


class ProxyScraper:
    def __init__(self, log_callback=None, progress_callback=None):
        self.log = log_callback or print
        self.progress = progress_callback or (lambda x: None)
        self.proxies = set()
        self.stop_flag = False
        self._host_next_allowed = {}
        self._host_pace_lock = asyncio.Lock()

    async def _pace_host(self, host):
        """Jaga jarak minimal antar-request ke host yang sama."""
        delay = HOST_MIN_DELAY.get(host, 0.0)
        if delay <= 0:
            return
        async with self._host_pace_lock:
            now = asyncio.get_event_loop().time()
            next_allowed = self._host_next_allowed.get(host, 0.0)
            wait = next_allowed - now
            self._host_next_allowed[host] = max(now, next_allowed) + delay + random.uniform(0, 0.4)
        if wait > 0:
            await asyncio.sleep(wait)

    async def fetch(self, session, source, semaphores):
        if self.stop_flag:
            return None, [], "stopped"
        name = source["name"]
        url = source["url"]
        host = urlparse(url).hostname or ""

        headers = dict(HEADERS)
        if host in EXTRA_HEADERS:
            headers.update(EXTRA_HEADERS[host])

        sem = semaphores.get(host)
        if sem is None:
            limit = HOST_CONCURRENCY_LIMITS.get(host, 10)
            sem = asyncio.Semaphore(limit)
            semaphores[host] = sem

        last_err = None
        attempt_timeouts = (20, 35, 35)

        for i, attempt_timeout in enumerate(attempt_timeouts):
            await self._pace_host(host)

            async with sem:
                try:
                    async with session.get(url, headers=headers, 
                                          timeout=aiohttp.ClientTimeout(total=attempt_timeout),
                                          ssl=False) as resp:
                        if resp.status == 200:
                            text = await resp.text()
                            found = extract_proxies(text)
                            if found:
                                return name, found, None

                            # 200 OK tapi 0 proxy
                            is_bot_wall = _looks_like_bot_wall(text)
                            if is_bot_wall and i < len(attempt_timeouts) - 1:
                                last_err = "200 OK tapi halaman kosong (anti-bot?), mencoba ulang..."
                                await asyncio.sleep(1.5 + random.random() * 1.5)
                                continue

                            snippet = re.sub(r"\s+", " ", text[:200]).strip()
                            reason = "anti-bot/kosong" if is_bot_wall else "markup berubah?"
                            return name, [], f"200 OK tapi 0 proxy ({reason}, {len(text)} bytes)"

                        last_err = f"HTTP {resp.status}"
                        if resp.status not in (403, 429, 503):
                            return name, [], last_err
                        await asyncio.sleep(1.0 + random.random())

                except asyncio.TimeoutError:
                    last_err = "Timeout"
                    await asyncio.sleep(0.5 + random.random())
                except Exception as e:
                    return name, [], str(e)[:160]

        return name, [], last_err

    async def run(self, max_results=None, workers=15):
        self.proxies.clear()
        self.stop_flag = False
        self._host_next_allowed.clear()

        total_sources = len(ALL_SOURCES)
        self.log(f"[*] Memulai scrape dari {total_sources} sumber (workers={workers})...")

        connector = aiohttp.TCPConnector(limit=workers, limit_per_host=5, ssl=False)
        semaphores = {}

        async with aiohttp.ClientSession(connector=connector, headers=HEADERS) as session:
            tasks = [self.fetch(session, src, semaphores) for src in ALL_SOURCES]
            total = len(tasks)
            done = 0
            raw_total = 0
            failed_count = 0

            for coro in asyncio.as_completed(tasks):
                if self.stop_flag:
                    break
                name, found, err = await coro
                done += 1
                self.progress(int(done / total * 100))

                if err:
                    failed_count += 1
                    self.log(f"[!] {name}: {err}")
                    continue

                raw_total += len(found)
                before = len(self.proxies)
                for p in found:
                    self.proxies.add(p)
                    if max_results and len(self.proxies) >= max_results:
                        break
                new = len(self.proxies) - before
                self.log(f"[+] {name}: {len(found)} ditemukan ({new} baru)")

                if max_results and len(self.proxies) >= max_results:
                    self.log("[*] Batas max results tercapai.")
                    break

        self.log(f"[*] Scrape selesai. Sumber gagal: {failed_count}/{total_sources} | "
                   f"Total mentah: {raw_total} | Total unik: {len(self.proxies)}")
        return list(self.proxies)
