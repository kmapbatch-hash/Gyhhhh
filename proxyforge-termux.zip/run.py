#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import sys

if __name__ == "__main__":
    print("=" * 60)
    print("   ProxyForge Termux Web Panel")
    print("   Open your browser at: http://localhost:8080")
    print("=" * 60)
    os.system(f"{sys.executable} app.py")
