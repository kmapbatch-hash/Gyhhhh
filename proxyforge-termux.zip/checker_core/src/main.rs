use std::env;
use std::fs;
use std::io::{self, BufRead};
use std::time::{Duration, Instant};
use reqwest::{Proxy, Client};
use serde::{Deserialize, Serialize};
use tokio::task;

#[derive(Serialize, Deserialize, Debug, Clone)]
struct ProxyResult {
    proxy: String,
    #[serde(rename = "type")]
    proxy_type: String,
    response_time: f64,
    status: String,
    timestamp: String,
}

#[derive(Serialize, Deserialize)]
struct Output {
    working: Vec<ProxyResult>,
    bad: Vec<String>,
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<String> = env::args().collect();
    if args.len() < 7 {
        eprintln!("Usage: checker_core <input_file> <output_file> <test_url> <timeout> <threads> <proxy_type>");
        std::process::exit(1);
    }

    let input_file = &args[1];
    let output_file = &args[2];
    let test_url = &args[3];
    let timeout: u64 = args[4].parse().unwrap_or(10);
    let threads: usize = args[5].parse().unwrap_or(50);
    let proxy_type = &args[6];

    let file = fs::File::open(input_file)?;
    let reader = io::BufReader::new(file);
    let proxies: Vec<String> = reader.lines().filter_map(|l| l.ok()).collect();

    println!("[RUST] Loaded {} proxies", proxies.len());
    println!("[RUST] Test URL: {}", test_url);
    println!("[RUST] Timeout: {}s | Threads: {} | Type: {}", timeout, threads, proxy_type);

    let client = Client::builder()
        .timeout(Duration::from_secs(timeout))
        .danger_accept_invalid_certs(true)
        .build()?;

    let mut handles = Vec::new();
    let semaphore = std::sync::Arc::new(tokio::sync::Semaphore::new(threads));

    for proxy_str in proxies.clone() {
        let client = client.clone();
        let test_url = test_url.clone();
        let proxy_type = proxy_type.clone();
        let sem = semaphore.clone();

        let handle = task::spawn(async move {
            let _permit = sem.acquire().await.unwrap();
            let start = Instant::now();

            let proxy_url = format!("http://{}", proxy_str);
            let proxy = match Proxy::all(&proxy_url) {
                Ok(p) => p,
                Err(_) => return None,
            };

            let test_client = match Client::builder()
                .timeout(Duration::from_secs(timeout))
                .danger_accept_invalid_certs(true)
                .proxy(proxy)
                .build() {
                Ok(c) => c,
                Err(_) => return None,
            };

            match test_client.get(&test_url).send().await {
                Ok(resp) => {
                    if resp.status().is_success() {
                        let elapsed = start.elapsed().as_secs_f64() * 1000.0;
                        let now = chrono::Local::now().format("%Y-%m-%d %H:%M:%S").to_string();
                        Some(ProxyResult {
                            proxy: proxy_str,
                            proxy_type,
                            response_time: (elapsed * 100.0).round() / 100.0,
                            status: "WORKING".to_string(),
                            timestamp: now,
                        })
                    } else {
                        None
                    }
                }
                Err(_) => None,
            }
        });
        handles.push(handle);
    }

    let mut working = Vec::new();
    let mut bad = Vec::new();
    let total = handles.len();
    let mut done = 0;

    for handle in handles {
        match handle.await {
            Ok(Some(result)) => {
                working.push(result);
                println!("[WORKING] {} - {}ms", working.last().unwrap().proxy, working.last().unwrap().response_time);
            }
            _ => {
                if let Some(p) = proxies.get(done) {
                    bad.push(p.clone());
                }
            }
        }
        done += 1;
        if done % 10 == 0 || done == total {
            println!("[RUST] Progress: {}/{}", done, total);
        }
    }

    let output = Output { working, bad };
    let json = serde_json::to_string_pretty(&output)?;
    fs::write(output_file, json)?;

    println!("[RUST] Done. Working: {} | Bad: {}", output.working.len(), output.bad.len());
    Ok(())
}
