# ⚡ ProxyForge Termux Edition

**All-in-One Proxy Scraper & Checker** untuk Termux (Android) — berjalan sebagai **Web Panel** di localhost, tanpa perlu root.

## 🎯 Fitur

| Fitur | Deskripsi |
|-------|-----------|
| **Scraper** | Otomatis scrape proxy gratis dari **177+ sumber** (68 GitHub + 109 Website) |
| **Checker** | Cek proxy mana yang masih hidup & cepat |
| **Rust Core** | Checker ditulis dalam Rust untuk performa maksimal (fallback ke Python) |
| **Web Panel** | GUI via browser (localhost:8080), tanpa perlu GUI desktop |
| **No Root** | Bisa jalan di Termux tanpa akses root |
| **Export** | Simpan hasil ke file .txt (scraped, working, fast, all) |
| **Copy to Clipboard** | Klik proxy di tabel untuk copy otomatis |

## 📦 Sumber Proxy (177+)

### GitHub Sources (68)
- clarketm/proxy-list, monosans/proxy-list, proxifly/free-proxy-list
- TheSpeedX/PROXY-List, ALIILAPRO/Proxy, r00tee/Proxy-List
- dpangestuw/Free-Proxy, hproxy-com/free-proxy-list
- ProxyScrape, openproxylist.xyz, proxyspace.pro
- Dan 50+ repo lainnya...

### Website Sources (109)
**China (CN/HK):**
- 89ip.cn, kuaidaili.com (11 halaman), ip3366.net (8 halaman)
- zdaye.com (8 halaman), kxdaili.com (11 halaman)

**Global:**
- free-proxy-list.net (7 kategori), spys.me, fineproxy.org (10 negara)
- proxybros.com, freeproxy.world, freeproxylist.cc
- proxyfreeonly.com (14 negara), vpnside.com
- ab57.ru, proxyspace.pro, freeproxyupdate.com

## 🚀 Cara Install & Jalankan di Termux

### 1. Install Termux
Download dari **F-Droid** (bukan Play Store!)

### 2. Update & Install Dependencies
```bash
pkg update && pkg upgrade -y
pkg install python rust git -y
```

### 3. Extract & Setup
```bash
cd /sdcard/Download  # atau folder download kamu
unzip proxyforge-termux.zip
cd proxyforge-termux
```

### 4. Install Python Dependencies
```bash
pip install flask aiohttp aiofiles requests
```

### 5. Build Rust Checker (Opsional tapi Direkomendasikan)
```bash
cd checker_core
cargo build --release
cd ..
cp checker_core/target/release/checker_core ./checker_bin
chmod +x checker_bin
```

Atau jalankan installer otomatis:
```bash
python requirement.py
```

### 6. Jalankan Web Panel
```bash
python run.py
# atau
python app.py
```

### 7. Buka Browser
- Di Termux: `termux-open http://localhost:8080`
- Atau buka browser Android → `http://localhost:8080`
- Dari HP lain di jaringan sama: `http://<IP-Termux>:8080`

## 🖥️ Cara Pakai

1. **Scrape Proxy**
   - Klik **Start Scrape**
   - 177+ sumber akan di-scrape otomatis
   - Tunggu progress bar sampai 100%
   - Hasil muncul di tab "Scraped"

2. **Check Proxy**
   - Setelah scrape selesai, klik **Start Check**
   - Atur timeout, threads, proxy type
   - Centang "Use Rust Core" untuk performa lebih cepat
   - Hasil muncul di tab Working & Fast

3. **Export / Copy**
   - Klik tombol Export untuk simpan ke file
   - Klik proxy di tabel untuk copy ke clipboard

## ⚙️ Konfigurasi

Edit file untuk mengubah:
- **Port server**: `app.py` (baris terakhir, default 8080)
- **Threshold Fast**: `app.py` (FAST_THRESHOLD, default 1000ms)
- **Sumber proxy**: `scraper.py` (tambah/hapus di GITHUB_SOURCES / WEBSITE_SOURCES)

## 🐛 Troubleshooting

| Masalah | Solusi |
|---------|--------|
| Port 8080 terpakai | Ubah port di `app.py` |
| Rust build gagal | Checker otomatis fallback ke Python |
| Scrape 0 hasil | Cek koneksi internet |
| Browser tidak akses | Pastikan firewall tidak blok port |
| `pip` tidak ditemukan | `pkg install python-pip -y` |

## 📄 File Structure

```
proxyforge-termux/
├── requirement.py      # Installer otomatis
├── run.py              # Shortcut jalankan
├── app.py              # Flask web server
├── scraper.py          # Engine scraper (177+ sources)
├── checker.py          # Engine checker (Python + Rust)
├── checker_core/       # Rust source code
│   ├── Cargo.toml
│   └── src/main.rs
├── templates/
│   └── index.html      # Web UI
├── proxies/            # Hasil export
│   ├── scraped/
│   ├── working/
│   └── fast/
└── README.md
```

## 📝 Catatan

- **Termux dari F-Droid** — versi Play Store sudah usang
- **Rust build opsional** — kalau gagal, Python checker tetap jalan
- **177+ sumber** — tidak semua sumber selalu online, yang mati akan di-skip otomatis
- **No root required** — semua fitur jalan tanpa root

## 🙏 Credits

Based on ProxyForge v3.6 & Matrix Proxy Checker
