#!/bin/bash
# ProxyForge Ubuntu Edition - Runner

cd "$(dirname "$0")"

if [ ! -d "venv" ]; then
    echo "[!] Virtual environment not found. Run ./setup.sh first."
    exit 1
fi

source venv/bin/activate

echo "========================================"
echo "   ProxyForge Ubuntu Web Panel"
echo "========================================"
echo "[*] Activating virtual environment..."
echo "[*] Starting Flask server..."
echo "[*] Open browser at: http://localhost:8080"
echo ""

python3 app.py
