# ⚡ ProxyForge Ubuntu Edition

**All-in-One Proxy Scraper & Checker** untuk Ubuntu/Debian — berjalan sebagai **Web Panel** di localhost.

Cocok untuk:
- Ubuntu chroot di Termux (proot-distro)
- WSL (Windows Subsystem for Linux)
- VPS/Cloud Ubuntu
- Desktop Ubuntu/Debian

---

## 🎯 Fitur

| Fitur | Deskripsi |
|-------|-----------|
| **Scraper** | Otomatis scrape proxy gratis dari **177+ sumber** (68 GitHub + 109 Website) |
| **Checker** | Cek proxy mana yang masih hidup & cepat |
| **Rust Core** | Checker ditulis dalam Rust untuk performa maksimal (fallback ke Python) |
| **Web Panel** | GUI via browser (localhost:8080), tanpa perlu GUI desktop |
| **Virtual Env** | Python packages terisolasi di venv |
| **Export** | Simpan hasil ke file .txt (scraped, working, fast, all) |
| **Copy to Clipboard** | Klik proxy di tabel untuk copy otomatis |

---

## 📦 Sumber Proxy (177+)

### GitHub Sources (68)
- clarketm/proxy-list, monosans/proxy-list, proxifly/free-proxy-list
- TheSpeedX/PROXY-List, ALIILAPRO/Proxy, r00tee/Proxy-List
- dpangestuw/Free-Proxy, hproxy-com/free-proxy-list
- ProxyScrape, openproxylist.xyz, proxyspace.pro
- SoliSpirit, proxylist-to, ProxyScraper (per protokol)
- Dan 50+ repo lainnya...

### Website Sources (109)

**China (CN/HK):**
- 89ip.cn, kuaidaili.com (11 halaman), ip3366.net (8 halaman)
- zdaye.com (8 halaman), kxdaili.com (11 halaman)

**Global:**
- free-proxy-list.net (7 kategori), spys.me, fineproxy.org (10 negara)
- proxybros.com, freeproxy.world, freeproxylist.cc
- proxyfreeonly.com (14 negara), vpnside.com
- ab57.ru, proxyspace.pro, freeproxyupdate.com

---

## 🚀 Cara Install & Jalankan

### Metode 1: Auto Setup (Direkomendasikan)

```bash
# 1. Extract ZIP
cd ~/Downloads  # atau folder mana saja
unzip proxyforge-ubuntu.zip
cd proxyforge-ubuntu

# 2. Run setup (install semua dependency + build Rust)
chmod +x setup.sh
./setup.sh

# 3. Jalankan
./run.sh
```

### Metode 2: Manual Setup

```bash
# 1. Extract & masuk folder
cd proxyforge-ubuntu

# 2. Install system dependencies
sudo apt-get update
sudo apt-get install -y python3 python3-pip python3-venv     curl wget git build-essential libssl-dev pkg-config

# 3. Install Rust (kalau belum ada)
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
source $HOME/.cargo/env

# 4. Buat virtual environment
python3 -m venv venv
source venv/bin/activate

# 5. Install Python packages
pip install flask aiohttp aiofiles requests

# 6. Build Rust checker
cd checker_core
cargo build --release
cd ..
cp checker_core/target/release/checker_core ./checker_bin
chmod +x checker_bin

# 7. Jalankan
python3 app.py
```

---

## 🖥️ Cara Pakai

1. **Scrape Proxy**
   - Buka browser → `http://localhost:8080`
   - Klik **Start Scrape**
   - 177+ sumber akan di-scrape otomatis
   - Tunggu progress bar sampai 100%

2. **Check Proxy**
   - Setelah scrape selesai, klik **Start Check**
   - Atur timeout, threads, proxy type
   - Centang "Use Rust Core" untuk performa lebih cepat
   - Hasil muncul di tab Working & Fast

3. **Export / Copy**
   - Klik tombol Export untuk simpan ke file
   - Klik proxy di tabel untuk copy ke clipboard

---

## 📁 File Structure

```
proxyforge-ubuntu/
├── setup.sh              # Auto-installer (Ubuntu/Debian)
├── run.sh                # Runner dengan venv
├── run.py                # Python fallback runner
├── app.py                # Flask web server
├── scraper.py            # Engine scraper (177+ sources)
├── checker.py            # Engine checker (Python + Rust)
├── checker_core/           # Rust source code
│   ├── Cargo.toml
│   └── src/main.rs
├── templates/
│   └── index.html        # Web UI
├── venv/                 # Python virtual environment
│   └── (auto-generated)
├── proxies/              # Hasil export
│   ├── scraped/
│   ├── working/
│   └── fast/
└── README.md
```

---

## ⚙️ Konfigurasi

Edit file untuk mengubah:
- **Port server**: `app.py` (baris terakhir, default 8080)
- **Threshold Fast**: `app.py` (FAST_THRESHOLD, default 1000ms)
- **Sumber proxy**: `scraper.py` (tambah/hapus di GITHUB_SOURCES / WEBSITE_SOURCES)

---

## 🐛 Troubleshooting

| Masalah | Solusi |
|---------|--------|
| Port 8080 terpakai | Ubah port di `app.py` |
| `sudo: command not found` | Jalankan tanpa sudo (sudah root di chroot) |
| Rust build gagal | Checker otomatis fallback ke Python |
| `venv` tidak ada | Jalankan `python3 -m venv venv` |
| Scrape 0 hasil | Cek koneksi internet |
| Browser tidak akses | Pastikan firewall tidak blok port |

---

## 📝 Catatan Khusus Ubuntu chroot di Termux

Kalau kamu pakai **proot-distro** atau **chroot** Ubuntu di Termux:

```bash
# Di Termux, masuk Ubuntu
proot-distro login ubuntu
# atau
./start-ubuntu.sh

# Di dalam Ubuntu chroot
cd /sdcard/Download/proxyforge-ubuntu
./setup.sh

# Jalankan
./run.sh

# Akses dari browser Android
# Buka: http://localhost:8080
# (port forwarding otomatis di Termux)
```

---

## 🙏 Credits

Based on ProxyForge v3.6 & Matrix Proxy Checker
